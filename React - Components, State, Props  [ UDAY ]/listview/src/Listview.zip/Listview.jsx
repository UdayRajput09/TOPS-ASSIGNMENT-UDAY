import React from "react";

function Fruits(props) {
  return <li>{props.name}</li>;
}

function Listview() {
  const fruits = ["Apple", "Banana", "Mango", "Orange"];

  return (
    <div>
      <h1>React way to render a list.</h1>
      <ul>
        {fruits.map((fruit, index) => (
          <Fruits key={index} name={fruit} />
        ))}
      </ul>
    </div>
  );
}

export default Listview;
